"""Data module for multimodal dataset loading and preprocessing."""

from .multimodal_dataset import MultimodalDataset

__all__ = ['MultimodalDataset']
