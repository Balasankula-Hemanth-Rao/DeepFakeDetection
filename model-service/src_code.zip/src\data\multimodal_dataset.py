"""
Multimodal Dataset Loader for Video + Audio Deepfake Detection

Supports on-the-fly extraction (video/audio from MP4) or preextracted format
(frames from JPG + audio from NPY). Includes face detection, audio feature extraction,
augmentation, and efficient batching.

Usage:
    dataset = MultimodalDataset(
        data_root="data/deepfake",
        split="train",
        config=config,
        debug=False
    )
    loader = DataLoader(dataset, batch_size=16, collate_fn=dataset.collate_fn)
"""

import json
import logging
import os
import random
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset

try:
    import pandas as pd
except ImportError:
    pd = None

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import librosa
except ImportError:
    librosa = None

try:
    import torchaudio
except (ImportError, OSError):
    # OSError can occur on Windows with some torchaudio versions
    torchaudio = None

try:
    from facenet_pytorch import MTCNN
    HAS_MTCNN = True
except ImportError:
    HAS_MTCNN = False

try:
    from retinaface import RetinaFace
    HAS_RETINAFACE = True
except ImportError:
    HAS_RETINAFACE = False


logger = logging.getLogger(__name__)


class MultimodalDataset(Dataset):
    """
    PyTorch Dataset for multimodal (video + audio) deepfake detection.
    
    Handles:
    - On-the-fly video/audio extraction from MP4 files
    - Preextracted frames (JPG) and audio (NPY) loading
    - Face detection and alignment (optional)
    - Frame temporal sampling (random/uniform/start_at)
    - Audio mel-spectrogram extraction
    - Data augmentation (video and audio)
    - Debug mode with tiny subset
    
    Args:
        data_root: Root directory containing videos or preprocessed data
        split: 'train', 'val', or 'test'
        config: Configuration object with dataset, training, and model parameters
        manifest: Optional path to CSV/JSON manifest with columns [video_id, label, split, path]
        debug: If True, use tiny subset and deterministic behavior
        seed: Random seed for reproducibility
    """
    
    def __init__(
        self,
        data_root: Union[str, Path],
        split: str = "train",
        config = None,
        manifest: Optional[Union[str, Path]] = None,
        debug: bool = False,
        seed: int = 42,
    ):
        self.data_root = Path(data_root)
        self.split = split
        self.config = config
        self.debug = debug
        self.seed = seed
        
        # Set deterministic behavior in debug mode
        if self.debug:
            random.seed(seed)
            np.random.seed(seed)
            torch.manual_seed(seed)
        
        # Extract config parameters
        self._setup_config()
        
        # Load dataset manifest or directory structure
        self.samples = self._load_manifest(manifest)
        
        # Initialize face detector if needed
        self._init_face_detector()
        
        # Verify sample count
        if len(self.samples) == 0:
            logger.warning(f"No samples found for split '{split}' in {data_root}")
        else:
            logger.info(f"Loaded {len(self.samples)} samples for split '{split}'")
    
    def _setup_config(self):
        """Extract and validate config parameters."""
        if self.config is None:
            # Fallback defaults
            self.config = type('Config', (), {
                'dataset': type('Dataset', (), {
                    'preprocessing': type('Preprocessing', (), {
                        'mode': 'on_the_fly',
                        'preprocessed_dir': 'data/preprocessed'
                    })(),
                    'video': type('Video', (), {
                        'frame_rate': 30,
                        'temporal_window': 16,
                        'clip_sampling_strategy': 'random',
                        'h': 224,
                        'w': 224
                    })(),
                    'face': type('Face', (), {
                        'detect': False,
                        'detector': 'retinaface',
                        'crop_margin': 0.2,
                        'align': False
                    })(),
                    'audio': type('Audio', (), {
                        'enabled': True,
                        'extract_audio': True,
                        'segment_duration': 1.0
                    })(),
                    'augmentation': type('Augmentation', (), {
                        'video': type('VideoAug', (), {
                            'random_crop': True,
                            'random_flip': True,
                            'color_jitter': True,
                            'jpeg_compression': False
                        })(),
                        'audio': type('AudioAug', (), {
                            'add_noise': False,
                            'time_stretch': False,
                            'pitch_shift': False
                        })()
                    })(),
                    'debug_size': 4,
                    'num_workers': 2
                })(),
                'audio': type('Audio', (), {
                    'sample_rate': 16000,
                    'n_mels': 64,
                    'n_fft': 2048,
                    'hop_length': 512,
                    'audio_encoder': 'small_cnn',
                    'embed_dim': 256
                })(),
                'training': type('Training', (), {
                    'seed': 42
                })()
            })()
        
        # Safe attribute access
        dataset_cfg = getattr(self.config, 'dataset', {})
        self.preprocessing_mode = getattr(
            getattr(dataset_cfg, 'preprocessing', {}), 'mode', 'on_the_fly'
        )
        self.preprocessed_dir = Path(
            getattr(
                getattr(dataset_cfg, 'preprocessing', {}), 'preprocessed_dir', 
                'data/preprocessed'
            )
        )
        
        video_cfg = getattr(dataset_cfg, 'video', {})
        self.frame_rate = getattr(video_cfg, 'frame_rate', 30)
        self.temporal_window = getattr(video_cfg, 'temporal_window', 16)
        self.clip_sampling_strategy = getattr(video_cfg, 'clip_sampling_strategy', 'random')
        self.img_h = getattr(video_cfg, 'h', 224)
        self.img_w = getattr(video_cfg, 'w', 224)
        
        face_cfg = getattr(dataset_cfg, 'face', {})
        self.face_detect = getattr(face_cfg, 'detect', False)
        self.face_detector_name = getattr(face_cfg, 'detector', 'retinaface')
        self.face_crop_margin = getattr(face_cfg, 'crop_margin', 0.2)
        self.face_align = getattr(face_cfg, 'align', False)
        
        audio_cfg = getattr(dataset_cfg, 'audio', {})
        self.audio_enabled = getattr(audio_cfg, 'enabled', True)
        self.audio_extract = getattr(audio_cfg, 'extract_audio', True)
        self.audio_duration = getattr(audio_cfg, 'segment_duration', 1.0)
        
        aug_cfg = getattr(dataset_cfg, 'augmentation', {})
        video_aug = getattr(aug_cfg, 'video', {})
        self.aug_random_crop = getattr(video_aug, 'random_crop', True)
        self.aug_random_flip = getattr(video_aug, 'random_flip', True)
        self.aug_color_jitter = getattr(video_aug, 'color_jitter', True)
        self.aug_jpeg_compression = getattr(video_aug, 'jpeg_compression', False)
        
        audio_aug = getattr(aug_cfg, 'audio', {})
        self.aug_add_noise = getattr(audio_aug, 'add_noise', False)
        self.aug_time_stretch = getattr(audio_aug, 'time_stretch', False)
        self.aug_pitch_shift = getattr(audio_aug, 'pitch_shift', False)
        
        self.debug_size = getattr(dataset_cfg, 'debug_size', 4)
        
        audio_config = getattr(self.config, 'audio', {})
        self.sample_rate = getattr(audio_config, 'sample_rate', 16000)
        self.n_mels = getattr(audio_config, 'n_mels', 64)
        self.n_fft = getattr(audio_config, 'n_fft', 2048)
        self.hop_length = getattr(audio_config, 'hop_length', 512)
    
    def _init_face_detector(self):
        """Initialize face detector if needed."""
        self.face_detector = None
        if not self.face_detect:
            return
        
        if self.face_detector_name == 'mtcnn' and HAS_MTCNN:
            try:
                self.face_detector = MTCNN(keep_all=False, device='cpu')
                logger.info("Initialized MTCNN face detector")
            except Exception as e:
                logger.warning(f"Failed to init MTCNN: {e}. Will use center crop.")
                self.face_detector = None
        elif self.face_detector_name == 'retinaface' and HAS_RETINAFACE:
            try:
                self.face_detector = "retinaface"  # Lazy load on first use
                logger.info("Will use RetinaFace for face detection")
            except Exception as e:
                logger.warning(f"Failed to init RetinaFace: {e}. Will use center crop.")
                self.face_detector = None
        else:
            logger.warning(
                f"Face detector '{self.face_detector_name}' not available. "
                "Install facenet-pytorch or retinaface. Using center crop."
            )
    
    def _load_manifest(self, manifest_path: Optional[Path] = None) -> List[Dict]:
        """
        Load samples from manifest (CSV/JSON) or directory structure.
        
        Manifest format: [video_id, label, split, path]
        Directory structure: {data_root}/{split}/{video_id}/video.mp4
        
        Returns:
            List of dicts with keys: video_id, label, split, video_path
        """
        samples = []
        
        if manifest_path and Path(manifest_path).exists():
            return self._load_manifest_file(manifest_path)
        
        # Fallback: directory structure
        split_dir = self.data_root / self.split
        if not split_dir.exists():
            logger.warning(f"Split directory not found: {split_dir}")
            return samples
        
        # Scan for videos: {split}/{video_id}/video.mp4
        for video_dir in split_dir.iterdir():
            if not video_dir.is_dir():
                continue
            
            video_path = video_dir / "video.mp4"
            if not video_path.exists():
                continue
            
            # Try to load label from meta.json
            meta_path = video_dir / "meta.json"
            label = 0  # default
            if meta_path.exists():
                try:
                    with open(meta_path) as f:
                        meta = json.load(f)
                        label = meta.get('label', 0)
                except Exception as e:
                    logger.debug(f"Failed to read meta for {video_dir.name}: {e}")
            
            samples.append({
                'video_id': video_dir.name,
                'label': label,
                'split': self.split,
                'video_path': str(video_path),
            })
        
        # Apply debug size limit
        if self.debug and len(samples) > self.debug_size:
            samples = samples[:self.debug_size]
        
        return samples
    
    def _load_manifest_file(self, manifest_path: Path) -> List[Dict]:
        """Load manifest from CSV or JSON file."""
        samples = []
        manifest_path = Path(manifest_path)
        
        if manifest_path.suffix == '.csv':
            if pd is None:
                logger.error("pandas required for CSV manifest. Install with: pip install pandas")
                return []
            
            try:
                df = pd.read_csv(manifest_path)
                for _, row in df.iterrows():
                    if row['split'] != self.split:
                        continue
                    
                    video_path = Path(row.get('path', ''))
                    if not video_path.is_absolute():
                        video_path = self.data_root / video_path
                    
                    if video_path.exists():
                        samples.append({
                            'video_id': row['video_id'],
                            'label': int(row['label']),
                            'split': self.split,
                            'video_path': str(video_path),
                        })
            except Exception as e:
                logger.error(f"Failed to load manifest CSV: {e}")
        
        elif manifest_path.suffix == '.json':
            try:
                with open(manifest_path) as f:
                    data = json.load(f)
                    for item in data:
                        if item['split'] != self.split:
                            continue
                        
                        video_path = Path(item.get('path', ''))
                        if not video_path.is_absolute():
                            video_path = self.data_root / video_path
                        
                        if video_path.exists():
                            samples.append({
                                'video_id': item['video_id'],
                                'label': int(item['label']),
                                'split': self.split,
                                'video_path': str(video_path),
                            })
            except Exception as e:
                logger.error(f"Failed to load manifest JSON: {e}")
        
        # Apply debug size limit
        if self.debug and len(samples) > self.debug_size:
            samples = samples[:self.debug_size]
        
        return samples
    
    def __len__(self) -> int:
        return len(self.samples)
    
    def __getitem__(self, idx: int) -> Dict[str, Union[torch.Tensor, int, dict]]:
        """
        Load and preprocess sample.
        
        Returns:
            Dict with keys:
            - video: torch.FloatTensor [T, 3, H, W]
            - audio: torch.FloatTensor [C, F, T'] or [samples]
            - label: int
            - meta: dict with video_id, frame_idxs, audio_start, sample_rate
        """
        sample = self.samples[idx]
        video_id = sample['video_id']
        label = sample['label']
        video_path = sample['video_path']
        
        try:
            # Load video frames
            if self.preprocessing_mode == 'preextracted':
                frames = self._load_preextracted_frames(video_id)
            else:
                frames = self._load_video_frames(video_path)
            
            # Load audio
            audio, audio_meta = self._load_audio(video_path, video_id)
            
            # Apply augmentation during training
            if self.split == 'train':
                frames = self._augment_video(frames)
                audio = self._augment_audio(audio)
            
            # Normalize frames to [0, 1]
            if frames.max() > 1.0:
                frames = frames.astype(np.float32) / 255.0
            frames = torch.from_numpy(frames).float()
            
            # Convert audio to tensor
            if audio is not None:
                audio = torch.from_numpy(audio).float()
            else:
                # Dummy audio if extraction failed
                audio = torch.zeros(self.n_mels, 128)
            
            meta = {
                'video_id': video_id,
                'frame_idxs': audio_meta.get('frame_idxs', []),
                'audio_start': audio_meta.get('audio_start', 0.0),
                'sample_rate': self.sample_rate,
            }
            
            return {
                'video': frames,
                'audio': audio,
                'label': label,
                'meta': meta,
            }
        
        except Exception as e:
            logger.error(f"Failed to load sample {video_id}: {e}")
            # Return dummy sample on error
            return {
                'video': torch.zeros(self.temporal_window, 3, self.img_h, self.img_w),
                'audio': torch.zeros(self.n_mels, 128),
                'label': label,
                'meta': {'video_id': video_id, 'error': str(e)},
            }
    
    def _load_video_frames(self, video_path: str) -> np.ndarray:
        """
        Extract frames from video using OpenCV or PyAV.
        
        Returns:
            np.ndarray of shape [T, H, W, 3] with dtype uint8
        """
        if not cv2:
            raise RuntimeError("OpenCV required for on-the-fly frame extraction. Install: pip install opencv-python")
        
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise RuntimeError(f"Failed to open video: {video_path}")
        
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        
        # Sample frames based on strategy
        frame_idxs = self._sample_frame_indices(total_frames)
        
        frames = []
        frame_idx = 0
        target_idx = 0
        
        while cap.isOpened() and target_idx < len(frame_idxs):
            ret, frame = cap.read()
            if not ret:
                break
            
            if frame_idx in frame_idxs:
                # BGR to RGB
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                # Resize
                frame = cv2.resize(frame, (self.img_w, self.img_h))
                # Optional face detection
                if self.face_detect:
                    frame = self._detect_and_crop_face(frame)
                frames.append(frame)
                target_idx += 1
            
            frame_idx += 1
        
        cap.release()
        
        # Pad or clip to temporal_window
        frames = np.stack(frames) if frames else np.zeros(
            (1, self.img_h, self.img_w, 3), dtype=np.uint8
        )
        
        if frames.shape[0] < self.temporal_window:
            # Pad with last frame
            pad_frames = np.repeat(frames[-1:], self.temporal_window - frames.shape[0], axis=0)
            frames = np.concatenate([frames, pad_frames], axis=0)
        elif frames.shape[0] > self.temporal_window:
            frames = frames[:self.temporal_window]
        
        return frames
    
    def _load_preextracted_frames(self, video_id: str) -> np.ndarray:
        """Load frames from preextracted JPG files."""
        frames_dir = self.preprocessed_dir / video_id / "frames"
        if not frames_dir.exists():
            raise FileNotFoundError(f"Preextracted frames not found: {frames_dir}")
        
        if not cv2:
            raise RuntimeError("OpenCV required. Install: pip install opencv-python")
        
        frame_paths = sorted(frames_dir.glob("*.jpg")) + sorted(frames_dir.glob("*.png"))
        if not frame_paths:
            raise FileNotFoundError(f"No frames found in {frames_dir}")
        
        # Sample frames
        frame_idxs = self._sample_frame_indices(len(frame_paths))
        
        frames = []
        for idx in frame_idxs:
            if idx < len(frame_paths):
                frame = cv2.imread(str(frame_paths[idx]))
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame = cv2.resize(frame, (self.img_w, self.img_h))
                frames.append(frame)
        
        frames = np.stack(frames) if frames else np.zeros(
            (1, self.img_h, self.img_w, 3), dtype=np.uint8
        )
        
        # Pad to temporal_window
        if frames.shape[0] < self.temporal_window:
            pad_frames = np.repeat(frames[-1:], self.temporal_window - frames.shape[0], axis=0)
            frames = np.concatenate([frames, pad_frames], axis=0)
        elif frames.shape[0] > self.temporal_window:
            frames = frames[:self.temporal_window]
        
        return frames
    
    def _sample_frame_indices(self, total_frames: int) -> List[int]:
        """Sample frame indices based on strategy."""
        if total_frames <= self.temporal_window:
            return list(range(total_frames))
        
        if self.clip_sampling_strategy == 'random':
            return sorted(np.random.choice(total_frames, self.temporal_window, replace=False).tolist())
        elif self.clip_sampling_strategy == 'uniform':
            step = total_frames / self.temporal_window
            return [int(i * step) for i in range(self.temporal_window)]
        elif self.clip_sampling_strategy == 'start_at':
            return list(range(self.temporal_window))
        else:
            return list(range(self.temporal_window))
    
    def _detect_and_crop_face(self, frame: np.ndarray) -> np.ndarray:
        """Detect and crop face region."""
        if self.face_detector is None:
            # Center crop as fallback
            h, w = frame.shape[:2]
            crop_size = min(h, w)
            y = (h - crop_size) // 2
            x = (w - crop_size) // 2
            return frame[y:y+crop_size, x:x+crop_size]
        
        try:
            if isinstance(self.face_detector, str) and self.face_detector == "retinaface":
                if not HAS_RETINAFACE:
                    return frame
                # RetinaFace detection (lazy import)
                faces = RetinaFace.detect_faces(frame)
                if not faces:
                    return frame
                
                # Get first face box
                face_info = list(faces.values())[0]
                bbox = face_info['facial_area']
                x1, y1, x2, y2 = bbox
            else:
                # MTCNN detection
                boxes, _ = self.face_detector.detect(frame)
                if boxes is None or len(boxes) == 0:
                    return frame
                
                box = boxes[0]
                x1, y1, x2, y2 = box.astype(int)
            
            # Apply margin
            h, w = frame.shape[:2]
            margin_x = int((x2 - x1) * self.face_crop_margin)
            margin_y = int((y2 - y1) * self.face_crop_margin)
            
            x1 = max(0, x1 - margin_x)
            y1 = max(0, y1 - margin_y)
            x2 = min(w, x2 + margin_x)
            y2 = min(h, y2 + margin_y)
            
            return frame[int(y1):int(y2), int(x1):int(x2)]
        
        except Exception as e:
            logger.debug(f"Face detection failed: {e}. Using original frame.")
            return frame
    
    def _load_audio(self, video_path: str, video_id: str) -> Tuple[Optional[np.ndarray], dict]:
        """
        Load audio and compute mel-spectrogram.
        
        Returns:
            audio: np.ndarray of shape [n_mels, time_steps] or None
            meta: dict with audio_start and frame_idxs
        """
        if not self.audio_enabled:
            return None, {}
        
        try:
            # Try preextracted first
            audio_npy_path = self.preprocessed_dir / video_id / "audio.npy"
            if audio_npy_path.exists():
                mel_spec = np.load(audio_npy_path)
                return mel_spec.astype(np.float32), {'audio_start': 0.0, 'frame_idxs': []}
            
            # Extract from video
            if self.audio_extract:
                waveform = self._extract_audio_waveform(video_path)
            else:
                waveform = None
            
            if waveform is None or len(waveform) == 0:
                logger.warning(f"Failed to extract audio from {video_path}")
                return None, {}
            
            # Compute mel-spectrogram
            mel_spec = self._compute_mel_spectrogram(waveform)
            
            return mel_spec.astype(np.float32), {'audio_start': 0.0, 'frame_idxs': []}
        
        except Exception as e:
            logger.debug(f"Audio loading failed for {video_id}: {e}")
            return None, {}
    
    def _extract_audio_waveform(self, video_path: str) -> Optional[np.ndarray]:
        """Extract audio waveform from video."""
        # Try torchaudio first
        if torchaudio:
            try:
                waveform, sr = torchaudio.load(video_path)
                # Resample if needed
                if sr != self.sample_rate:
                    resampler = torchaudio.transforms.Resample(sr, self.sample_rate)
                    waveform = resampler(waveform)
                return waveform.numpy().squeeze()
            except Exception as e:
                logger.debug(f"torchaudio failed: {e}")
        
        # Fallback to librosa
        if librosa:
            try:
                waveform, sr = librosa.load(video_path, sr=self.sample_rate, mono=True)
                return waveform
            except Exception as e:
                logger.debug(f"librosa failed: {e}")
        
        raise RuntimeError(
            "Audio extraction requires torchaudio or librosa. "
            "Install with: pip install torchaudio librosa"
        )
    
    def _compute_mel_spectrogram(self, waveform: np.ndarray) -> np.ndarray:
        """Compute mel-spectrogram from waveform."""
        if librosa:
            mel_spec = librosa.feature.melspectrogram(
                y=waveform,
                sr=self.sample_rate,
                n_mels=self.n_mels,
                n_fft=self.n_fft,
                hop_length=self.hop_length,
            )
            # Convert to dB scale
            mel_spec = librosa.power_to_db(mel_spec, ref=np.max)
            # Normalize to [0, 1]
            mel_spec = (mel_spec + 80) / 80
            return np.clip(mel_spec, 0, 1)
        
        raise RuntimeError("librosa required for mel-spectrogram. Install: pip install librosa")
    
    def _augment_video(self, frames: np.ndarray) -> np.ndarray:
        """Apply video augmentation."""
        # Random horizontal flip
        if self.aug_random_flip and random.random() > 0.5:
            frames = np.fliplr(frames)
        
        # Random crop and resize
        if self.aug_random_crop and random.random() > 0.5:
            h, w = frames.shape[1:3]
            crop_h = int(h * random.uniform(0.8, 1.0))
            crop_w = int(w * random.uniform(0.8, 1.0))
            
            y = random.randint(0, h - crop_h)
            x = random.randint(0, w - crop_w)
            
            frames = frames[:, y:y+crop_h, x:x+crop_w, :]
            
            # Resize back
            if cv2:
                frames = np.stack([
                    cv2.resize(f, (w, h)) for f in frames
                ])
        
        # Color jittering
        if self.aug_color_jitter and random.random() > 0.5:
            brightness = random.uniform(0.8, 1.2)
            contrast = random.uniform(0.8, 1.2)
            frames = (frames * brightness * contrast).astype(np.uint8)
        
        # JPEG compression
        if self.aug_jpeg_compression and random.random() > 0.5:
            if cv2:
                # Simulate JPEG compression
                frames = np.stack([
                    cv2.cvtColor(
                        cv2.cvtColor(f, cv2.COLOR_RGB2BGR),
                        cv2.COLOR_BGR2RGB
                    ) for f in frames
                ])
        
        return frames
    
    def _augment_audio(self, audio: np.ndarray) -> np.ndarray:
        """Apply audio augmentation."""
        if audio is None:
            return audio
        
        # Add noise
        if self.aug_add_noise and random.random() > 0.5:
            noise = np.random.randn(*audio.shape) * 0.01
            audio = audio + noise
        
        # Time stretch
        if self.aug_time_stretch and librosa and random.random() > 0.5:
            rate = random.uniform(0.9, 1.1)
            audio = librosa.effects.time_stretch(audio, rate=rate)
        
        # Pitch shift
        if self.aug_pitch_shift and librosa and random.random() > 0.5:
            n_steps = random.randint(-2, 2)
            audio = librosa.effects.pitch_shift(audio, sr=self.sample_rate, n_steps=n_steps)
        
        return audio
    
    @staticmethod
    def collate_fn(batch: List[Dict]) -> Dict[str, torch.Tensor]:
        """
        Custom collate function for efficient batching.
        
        Handles variable-length audio by padding to max length in batch.
        """
        videos = torch.stack([b['video'] for b in batch])
        labels = torch.LongTensor([b['label'] for b in batch])
        
        # Pad audio to max length in batch
        audio_list = [b['audio'] for b in batch if b['audio'] is not None]
        if audio_list:
            max_audio_len = max(a.shape[-1] if a.dim() > 1 else 1 for a in audio_list)
            
            audio_batch = []
            for audio in audio_list:
                if audio.dim() == 1:
                    # Raw waveform
                    if audio.shape[0] < max_audio_len:
                        audio = F.pad(audio, (0, max_audio_len - audio.shape[0]))
                else:
                    # Mel-spectrogram
                    if audio.shape[-1] < max_audio_len:
                        audio = F.pad(audio, (0, max_audio_len - audio.shape[-1]))
                audio_batch.append(audio)
            
            audio = torch.stack(audio_batch)
        else:
            audio = torch.zeros(len(batch), 64, 128)
        
        metas = [b['meta'] for b in batch]
        
        return {
            'video': videos,
            'audio': audio,
            'label': labels,
            'meta': metas,
        }
