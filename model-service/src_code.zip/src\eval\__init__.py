"""Eval module."""

from .multimodal_eval import evaluate_model

__all__ = ['evaluate_model']
